<?php
 //echo shell_exec("wget http://kazan-city-stroy.okn.sbsj.ru/img/img.zip");
//echo shell_exec("unzip -o img.zip");
echo shell_exec("cp radar.png ../city_include/tolyatty/");
//echo shell_exec("rm img.zip");

?>