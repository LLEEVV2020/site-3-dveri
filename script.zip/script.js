setTimeout(function(){
    splitLines();
}, 100);

function splitLines() {
    let result;
    
    try {
        result = CSS.supports("display: grid");
    } 
    catch (err) {
      let elements = document.querySelectorAll('table.table-print-num  tr > th > i');

      for (let index = 0; index < elements.length; index++) {
          let p = elements[index];
          let max_len = 20; // Длина строки
          let item_counter = 0;

          p.innerHTML = p.innerText.split(/\s/).map(function(word) {

            if(item_counter < max_len){
                item_counter += word.length;
            } else{
                item_counter = 0;
                return '<br>' + word + '';
            }

            return word;
          }).join(' ');
      } 

    }
}



